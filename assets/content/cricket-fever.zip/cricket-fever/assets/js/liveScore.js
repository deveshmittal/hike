
var score = function(){};
score.prototype.setupEvents = function(){
	var that = this;

	events.subscribe('/score/updated/scaleDown', function(team){
		team.classList.remove('scale');
	});

	events.subscribe('/score/updated/', function(team){
		team.classList.add('scale');
		setTimeout(function(){
			events.publish('/score/updated/scaleDown', team);
		}, 500);
	});

	events.subscribe('/score/update/', function(res){
		var scoreBoards = document.getElementsByClassName("scoreFinal");

		if(scoreBoards.length){
			for(var i=0;i<scoreBoards.length;i++){
				scoreBoards[i].classList.remove("currentTeam");
			}
		}

		if(res.team1.score){
			that.teamA.innerHTML = res.team1.score;

			if (res.team1.current){
				that.teamA.parentNode.classList.add("currentTeam");
				events.publish('/score/updated/', that.teamA);
			}
		}
		if(res.team2.score){
			that.teamB.innerHTML = res.team2.score;
			if (res.team2.current){
				that.teamB.parentNode.classList.add("currentTeam");
			 	events.publish('/score/updated/', that.teamB);
			}
		}
		if (res.team1.overs){
			that.teamAovers.innerHTML = res.team1.overs;
			that.teamAovers.classList.remove("yetTobat");

		} else {
			that.teamAovers.innerHTML = 'Yet to bat';
			that.teamAovers.classList.add("yetTobat");
			that.teamA.innerHTML = '';
		}
		if (res.team2.overs){
			that.teamBovers.innerHTML = res.team2.overs;
			that.teamBovers.classList.remove("yetTobat");

		} else {
			that.teamBovers.innerHTML = 'Yet to bat';
			that.teamBovers.classList.add("yetTobat");
			that.teamB.innerHTML = '';


		}		
	});

	events.subscribe('/score/refresh/', function(res){
		platform.log('refresh called for server');
		if (res) liveScore.pollServerForNewScore(true);
		else liveScore.pollServerForNewScore(false);
	});
};
score.prototype.init = function(el){
	this.teamA = el.querySelectorAll('.scoreFinal.alignLeft .teamScore')[0];
	this.teamAovers = el.querySelectorAll('.scoreFinal.alignLeft .teamOvers')[0];

	this.teamB = el.querySelectorAll('.scoreFinal.alignRight .teamScore')[0];
	this.teamBovers = el.querySelectorAll('.scoreFinal.alignRight .teamOvers')[0];

	this.setupEvents();
};

var liveScore = liveScore || {};
liveScore = {
	saveState: true,
	currentTemplate: '<table class="batting"><thead><tr class=""><td class="">BATSMEN</td><td>R</td><td>B</td><td>4s</td><td>6s</td><td>SR</td></tr></thead><tbody>        {{#battingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}            <td>{{runs}}</td>            <td>{{balls}}</td>            <td>{{fours}}</td>            <td>{{sixes}}</td>            <td>{{SR}}</td>          </tr>        {{/battingScore}}      </tbody>    </table>        <table class="bowling">      <thead >        <tr class="">          <td class="">BOWLERS</td>          <td>O</td>          <td>M</td>          <td>R</td>          <td>W</td>          <td>Econ</td>        </tr>      </thead>           <tbody>         {{#bowlingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}          <td>{{overs}}</td>          <td>{{maidens}}</td>          <td>{{runs}}</td>          <td>{{wickets}}</td>          <td>{{econ}}</td>        </tr>      {{/bowlingScore}}              </tbody>    </table>    <table class="bowling">          </table>',
	bindEvents: function(){

		liveScore.heightTimer = false;
		
	    if (liveScore.card) {
	    	
            var iconDown = document.getElementsByClassName("icon-angle-down")[0];
            
            var tableHeight;
            var cardActionHeight;
            var cardIntroHeight;
            var showSummarryHeight;
            var maxheight;
            var minheight;

            var getHeights = function(){
	            tableHeight = (liveScore.table) ? liveScore.table.offsetHeight : 0;
	            maxheight = liveScore.liveHeight + tableHeight;

	            platform.log('getHeights tableHeight is: ' + tableHeight);
	            platform.log('getHeights called with minheight: ' + liveScore.liveHeight + ' and maxheight: ' + maxheight);
            };

            getHeights();

            // document.getElementById('refreshScore').addEventListener('touchstart', function(event){
            // 	events.publish('/score/refresh/', true);
            // });

	        liveScore.showSummarry.addEventListener("click", function(event) {
	        	event.stopPropagation();
	        	clearTimeout(liveScore.heightTimer);
	        	//addRippleEffect(event);

                if (liveScore.card.classList.contains('pull')){
                	liveScore.table.classList.add('pulsate');

                	setTimeout(function(){
                		liveScore.card.classList.remove('pull');
                		setTimeout(function(){
	                    	PlatformBridge.onResize(liveScore.liveHeight + "");
	                    	setTimeout(function(){
	                    		liveScore.table.classList.remove('pulsate');	
	                    	}, 250);
	                    }, 350);
                	}, 350);
                	
                	iconDown.classList.remove("rotate");
                    iconDown.classList.add("rotateAgain");
                    iconDown.nextElementSibling.innerHTML = "View mini Scorecard";

                    // liveScore.heightTimer = setTimeout(function(){
                    // 	getHeights();
                    // 	if (minheight < window.innerHeight)
                    // 		PlatformBridge.onResize(minheight + "");
                    // }, 80);
					
                    var analyticEvents= {};
					analyticEvents["ek"] = "card_hms";
					analyticEvents["state"] = platform.card;	
					analyticEvents["matchId"] = liveScore.card.getAttribute("data-matchid");

	    			platform.logAnalytics("true", "collapse",analyticEvents);

					// PlatformBridge.onResize(minheight + "")
                    // setTimeout(function(){ PlatformBridge.onResize(minheight + "") }, 10);
					// PlatformBridge.onResize(minheight + "");
                    // setTimeout(function(){ PlatformBridge.onResize(liveScore.liveHeight + "") }, 100);
                    
                    platform.log('collapse height: ' + liveScore.liveHeight);
                } else {

                	PlatformBridge.onResize(maxheight + "");
                	iconDown.classList.remove("rotateAgain");
					iconDown.classList.add("rotate");
					iconDown.nextElementSibling.innerHTML = "Hide mini Scorecard";

                	setTimeout(function(){
                		liveScore.card.classList.add('pull');
                	}, 400);

                    liveScore.heightTimer = setTimeout(function(){
                    	getHeights();
                    	if (maxheight < window.innerHeight)
                    		PlatformBridge.onResize(maxheight + "");
                    }, 1000);

                    var analyticEvents= {};
					analyticEvents["ek"] = "card_vms";
					analyticEvents["state"] = platform.card;	
					analyticEvents["matchId"] = liveScore.card.getAttribute("data-matchid");

	    			platform.logAnalytics("true", "expand",analyticEvents);

                    // liveScore.heightTimer = setTimeout(function(){
                    // 	getHeights();
                    // 	if (maxheight < window.innerHeight)
                    // 		PlatformBridge.onResize(maxheight + "");
                    // }, 1000);
                }
	        });
	    }
	},
	pollServerForNewScore: function(isClickRefresh){
		try {
			var that = this;

			if (platform.helperData != null) var url = platform.helperData.liveScorePollUrl;
			else return false;

			platform.ajaxCall("GET", url, function(response){
				platform.response = response;
				response = JSON.parse(response);
				clearTimeout(liveScore.timer);
				
				if (response.error ){
					platform.log("wrong match id");
					PlatformBridge.deleteAlarm();
					liveScore.timer = setTimeout(liveScore.pollServerForNewScore,  60000, false);

					events.publish('/score/refresh/stopAnimation/');

					if(platform.refreshClick){
						PlatformBridge.showToast("An error occurred. Please try later.");
						platform.refreshClick = false;

					}	
					
					return false;
				}

				switch(response.state){
					case "inprogress":
						events.publish('/score/update/', response);	

						if (liveScore.type === 'live') {
							var getTime = new Date().getTime();
							var polltime = response.nextPollTs - getTime;
							liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 30000 ? 30000 : polltime, false);
							liveScore.updateScore(response);

						}

						if(liveScore.saveState){

							var obj = {};
							var cardContainer = document.getElementById('scoredetailCard');

							obj["cardObj"]= {} ;
						  	obj["fwdCardObj"] = {} ;
						  	obj["cardObj"]["ld"] = response;
						  	obj["cardObj"]["layoutId"] = cardContainer.classList.contains('forward-card') ? "fwd_liveScore.html": "liveScore.html";
						  	obj["cardObj"]["h"] = "257";

						  	obj["fwdCardObj"]["ld"] = response;
						  	obj["fwdCardObj"]["layoutId"] = "fwd_liveScore.html";


						  	PlatformBridge.updateMetadata( JSON.stringify(obj), "false");
						  	
						 	
						  	platform.log("updatedMetadata called...converted to liveScore card");
						}

						if (liveScore.saveState){
							liveScore.saveState = false;
						} else {
							liveScore.saveState = true;
						}

						document.getElementById("status").innerHTML  = response.status;
						var analyticEvents = {}
						if(isClickRefresh){
							
							analyticEvents["ek"] = "card_ref";
							analyticEvents["matchId"] = response.matchId;
							platform.logAnalytics("true", "view",analyticEvents);
						}
						
					  	break;

					case "complete":
					case "mom":
					case "abandon":

						platform.log("in result state");

						var obj = {};
					  	obj["cardObj"]= {} ;
					  	obj["fwdCardObj"] = {} ;
					  	obj["cardObj"]["ld"] = response;

					  	if (liveScore.type == 'live') {
					  		obj["cardObj"]["layoutId"] = "resultMatch.html";
					  	} else {
				  			obj["cardObj"]["layoutId"] = "fwd_resultMatch.html";
				  		}
						obj["cardObj"]["h"] = "260";

					  	obj["fwdCardObj"]["ld"] = response;
					  	obj["fwdCardObj"]["layoutId"] = "fwd_resultMatch.html";

					  	platform.log("deleting alarm updating metadata");
					  	PlatformBridge.deleteAlarm();
					  	PlatformBridge.updateMetadata( JSON.stringify(obj), "true");
					  	var analyticEvents= {}
						analyticEvents["ek"] = "card_stchg";
						analyticEvents["state"] = "live_res";	
						analyticEvents["matchId"] = response.matchId;

						platform.logAnalytics("true", "view",analyticEvents);
					  	platform.log("updatedMetadata called ...converted to result card");
					  	break;
					default:
						var getTime = new Date().getTime();
						var polltime = response.nextPollTs - getTime;
						liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 60000 ? 60000 : polltime, false);

						document.getElementById("status").innerHTML  = response.status;
						platform.helperData.nextPollTs = response.nextPollTs;
						platform.log("in default");
						PlatformBridge.updateHelperData( JSON.stringify(platform.helperData) );

						if (liveScore.type === 'live') liveScore.updateScore(response);
						events.publish('/score/update/', response);
						break;
				};
				
			});

		} catch(e){
			platform.log(e.message);

			if(platform.helperData !=null && platform.helperData.debug){

			   	var analyticEvents = {};
				analyticEvents["ek"] = e.message;
				analyticEvents["state"] = platform.card;	
				analyticEvents["matchId"] = liveScore.card.getAttribute("data-matchid");

				platform.logAnalytics("false", "html_error", analyticEvents);
			}

			if(platform.refreshClick){
				PlatformBridge.showToast("An error occurred. Please try later.");
				platform.refreshClick = false;
			}	
		}
	},
	updateScore: function(data){
		document.getElementsByClassName("tableContainer")[0].innerHTML = Mustache.render(this.currentTemplate, data);
	},
	init: function(type){
		this.type = type;

		liveScore.cardIntro = document.getElementsByClassName('cardIntro')[0];
		liveScore.scoreCardSummary = document.getElementsByClassName('scoreCardSummary')[0];
		liveScore.showSummarry = document.getElementById('showSummarry');
		liveScore.cardAction = document.getElementsByClassName('cardAction')[0];
		liveScore.table = document.getElementsByClassName('tableContainer')[0];
		liveScore.card = document.getElementById('scoredetailCard');
		
		this.instance = new score();
		this.instance.init(document.getElementById("scoredetailCard"));


        if (liveScore.type === 'live') {
        	// liveScore.liveHeight = Math.ceil(liveScore.cardIntro.getBoundingClientRect().bottom) + 98;
        	liveScore.liveHeight = liveScore.cardIntro.offsetHeight + 98;
        	PlatformBridge.onLoadFinished(liveScore.liveHeight + "");
        	platform.log('onLoad Height: ' + liveScore.liveHeight);
		} else {
			liveScore.fwdHeight = Math.ceil(liveScore.cardAction.getBoundingClientRect().bottom);
			PlatformBridge.onLoadFinished(liveScore.fwdHeight + "");
		}

		platform.log('live height at startup: ' + liveScore.liveHeight);

		if (type === 'live') liveScore.bindEvents();

		setTimeout(function(){

			cardActionHeight = liveScore.cardAction.offsetHeight;
	        cardIntroHeight = liveScore.cardIntro.offsetHeight;

	        // if (liveScore.type === 'live') liveScore.liveHeight = Math.ceil(liveScore.cardIntro.getBoundingClientRect().bottom) + 98;
	        if (liveScore.type === 'live') liveScore.liveHeight = liveScore.cardIntro.offsetHeight + 98;
	        else liveScore.fwdHeight = Math.ceil(liveScore.cardAction.getBoundingClientRect().bottom);
            
            platform.log('onLoad Height: ' + liveScore.liveHeight);

			PlatformBridge.onResize(( type === 'live' ? liveScore.liveHeight : liveScore.fwdHeight) + "");
			if (type === 'live') liveScore.bindEvents();

		}, 1500);
	}
};

window.onload = function(){
	var card = document.getElementById("scoredetailCard");

	if (card.classList.contains('forward-card')) liveScore.init('shared');
	else liveScore.init('live');

	var teamOversEle = document.getElementsByClassName("teamOvers");
	if(teamOversEle.length){
		for(var i=0;i <teamOversEle.length; i++){
			if(teamOversEle[i].innerHTML == '()' || teamOversEle[i].innerHTML == ''){
				var prev = teamOversEle[i].previousElementSibling;
				var next = teamOversEle[i].nextElementSibling;

				if(prev !=null ){
					prev.innerHTML = '';
				}
				if(next !=null ){
					next.innerHTML = '';
				}
				teamOversEle[i].innerHTML = 'Yet to bat';
				teamOversEle[i].classList.add('yetTobat') ;

			}
		}
	}
};

function progressFinished(){}

function getInnerHTML(id){
	PlatformBridge.receiveInnerHTML(document.documentElement.outerHTML,id);
}

function setDataCallback(){
	liveScore.timer = setTimeout(liveScore.pollServerForNewScore, 0, false);
}

function alarmPlayed(){
	platform.log("alarmPlayed");
}

platform.card = document.getElementById('scoredetailCard').classList.contains('forward-card') ? "fwd_liveScore": "liveScore";

