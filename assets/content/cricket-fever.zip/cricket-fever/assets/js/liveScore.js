
var score = function(){};
score.prototype.setupEvents = function(){
	var that = this;

	events.subscribe('/status/update/', function(res){

	});

	events.subscribe('/score/update/', function(res){
		if(res.team1.score){
			that.teamA.innerHTML = res.team1.score;
		}
		if(res.team2.score){
			that.teamB.innerHTML = res.team2.score;
		}
		if (res.team1.overs){
			that.teamAovers.innerHTML = '('+res.team1.overs+')';
		} else {
			that.teamAovers.innerHTML = '';
		}
		if (res.team2.overs){
			that.teamBovers.innerHTML = '('+res.team2.overs+')';
		} else {
			that.teamBovers.innerHTML = '';
		}
	});

	events.subscribe('/score/refresh/startAnimation/', function(){
		document.getElementsByClassName('icon-cog')[0].classList.add('play');
	});

	events.subscribe('/score/refresh/stopAnimation/', function(){
		document.getElementsByClassName('icon-cog')[0].classList.remove('play');
	});

	events.subscribe('/score/refresh/', function(res){
		events.publish('/score/refresh/startAnimation/');
		liveScore.pollServerForNewScore();
	});
};
score.prototype.init = function(el){
	this.teamA = el.querySelectorAll('.scoreFinal.alignLeft span')[0];
	this.teamAovers = el.querySelectorAll('.scoreFinal.alignLeft span')[1];

	this.teamB = el.querySelectorAll('.scoreFinal.alignRight span')[1];
	this.teamBovers = el.querySelectorAll('.scoreFinal.alignRight span')[0];

	this.setupEvents();
};

var liveScore = liveScore || {};
liveScore = {
	saveState: true,
	currentTemplate: '<table class="batting"><thead><tr class=""><td class="">BATSMEN</td><td>R</td><td>B</td><td>4s</td><td>6s</td><td>SR</td></tr></thead><tbody>        {{#battingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}            <td>{{runs}}</td>            <td>{{balls}}</td>            <td>{{fours}}</td>            <td>{{sixes}}</td>            <td>{{SR}}</td>          </tr>        {{/battingScore}}      </tbody>    </table>        <table class="bowling">      <thead >        <tr class="">          <td class="">BOWLERS</td>          <td>O</td>          <td>M</td>          <td>R</td>          <td>W</td>          <td>Econ</td>        </tr>      </thead>           <tbody>         {{#bowlingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}          <td>{{overs}}</td>          <td>{{maidens}}</td>          <td>{{runs}}</td>          <td>{{wickets}}</td>          <td>{{econ}}</td>        </tr>      {{/bowlingScore}}              </tbody>    </table>    <table class="bowling">          </table>',
	bindEvents: function(){

		var element = document.getElementsByClassName("scoreCardSummary")[0];
		var card = document.getElementById('scoredetailCard');

	    if (element) {
	    	
	    	var element = document.getElementsByClassName("scoreCardSummary")[0];
            var iconDown = document.getElementsByClassName("icon-angle-down")[0];
            var height = document.getElementsByClassName('scoreCardSummary')[0].clientHeight;
            var cardActionHeight = document.getElementsByClassName('cardAction')[0].clientHeight;
            var innerHeight = card.clientHeight;

            var maxheight = innerHeight + height;
            var minheight = innerHeight + cardActionHeight;

            document.getElementById('refreshScore').addEventListener('touchstart', function(event){
            	events.publish('/score/refresh/');
            });

	        document.getElementsByTagName("body")[0].addEventListener("click", function(event) {
	        	event.stopPropagation();
	            if (event.target.id == "showSummarry" || event.target.parentNode.id == "showSummarry") {

	                if (card.classList.contains('pull')){
	                	card.classList.remove('pull');
	                	iconDown.classList.remove("rotate");
	                    iconDown.classList.add("rotateAgain");
	                    iconDown.nextElementSibling.innerHTML = "View mini Scorecard";
	                    setTimeout(function(){ PlatformBridge.onResize(minheight + "") }, 300);
	                } else {
	                	card.classList.add('pull');
	                	iconDown.classList.remove("rotateAgain");
	                    iconDown.classList.add("rotate");
	                    iconDown.nextElementSibling.innerHTML = "Hide mini Scorecard";

	                    PlatformBridge.onResize(maxheight + "");
	                }

	            }
	        });
	    }
	},
	pollServerForNewScore: function(){
		var that = this;

		if (platform.helperData != null) var url = platform.helperData.liveScorePollUrl;
		else return false;

		platform.ajaxCall("GET", url, function(response){
			
			platform.log(response );
			platform.response = response;
			response = JSON.parse(response);
			clearTimeout(liveScore.timer);
			
			if(response.error ){
				platform.log("wrong match id");
				PlatformBridge.deleteAlarm(platform.messageId);
				liveScore.timer = setTimeout(liveScore.pollServerForNewScore,  60000);

				events.publish('/score/refresh/stopAnimation/');
				return false;
			}

			switch(response.state){
				case "inprogress":
					events.publish('/score/update/', response);	

					if (liveScore.type === 'live') {
						var getTime = new Date().getTime();
						var polltime = response.nextPollTs - getTime;
						liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 10000 ? 10000 : polltime);
						liveScore.updateScore(response);
					}

					if(liveScore.saveState){

						var obj = {};
						obj["cardObj"]= {} ;
					  	obj["fwdCardObj"] = {} ;
					  	obj["cardObj"]["ld"] = response;
					  	obj["cardObj"]["layoutId"] = "liveScore.html";
					  	obj["cardObj"]["h"] = "257";

					  	obj["fwdCardObj"]["ld"] = response;
					  	obj["fwdCardObj"]["layoutId"] = "fwd_liveScore.html";

					  	//PlatformBridge.deleteAlarm(platform.messageId);
					  //	if (liveScore.type === 'live') {

					  		PlatformBridge.updateMetadata(platform.messageId, JSON.stringify(obj), "false");
					  	//}
					 	
					  	platform.log("updatedMetadata called...converted to liveScore card");
					}

					if (liveScore.saveState){
						liveScore.saveState = false;
					} else {
						liveScore.saveState = true;
					}

					document.getElementById("status").innerHTML  = response.status;
				  	break;

				case "complete":
				case "mom":
				case "abandon":
					platform.log("in result state");

					if (liveScore.type === 'live') {
						var obj = {};
					  	obj["cardObj"]= {} ;
					  	obj["fwdCardObj"] = {} ;
					  	obj["cardObj"]["ld"] = response;
					  	obj["cardObj"]["layoutId"] = "resultMatch.html";
						obj["cardObj"]["h"] = "260";

					  	obj["fwdCardObj"]["ld"] = response;
					  	obj["fwdCardObj"]["layoutId"] = "fwd_resultMatch.html";

					  	platform.log("deleting alarm updating metadata");
					  	PlatformBridge.deleteAlarm(platform.messageId);
					  	PlatformBridge.updateMetadata(platform.messageId, JSON.stringify(obj), "true");

					  	platform.log("updatedMetadata called ...converted to result card");
				  	}else{
				  		PlatformBridge.deleteAlarm(platform.messageId);
				  		document.getElementById("status").innerHTML  = response.status;
						platform.helperData.nextPollTs = response.nextPollTs;
				  	}

				  	break;
				default:
					var getTime = new Date().getTime();
					var polltime = response.nextPollTs - getTime;
					liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 10000 ? 10000 : polltime);

					document.getElementById("status").innerHTML  = response.status;
					platform.helperData.nextPollTs = response.nextPollTs;
					platform.log("in default");
					PlatformBridge.updateHelperData(platform.messageId, JSON.stringify(platform.helperData) );
					
					break;
			};

			events.publish('/score/refresh/stopAnimation/');
		});
	},
	updateScore: function(data){
		document.getElementsByClassName("tableContainer")[0].innerHTML = Mustache.render(this.currentTemplate, data);
	},
	init: function(type){
		this.type = type;
		this.bindEvents();
		this.instance = new score();
		this.instance.init(document.getElementById("scoredetailCard"));

		var card = document.getElementById('scoredetailCard').clientHeight;
		var action = document.getElementsByClassName('cardAction')[0].clientHeight;
		var height = card + action;

		if (type === 'live') PlatformBridge.onLoadFinished(height + "");
		else if (type === 'shared') PlatformBridge.onLoadFinished(card + "");

		// setTimeout(function(){
		// 	var card = document.getElementById('scoredetailCard').clientHeight;
		// 	var action = document.getElementsByClassName('cardAction')[0].clientHeight;
		// 	var height = card + action;
		// 	switch(type){
		// 		case 'live':
		// 		if ((window.innerHeight - (type === 'live' ? height : card)) > 40){
		// 			PlatformBridge.onResize(( type === 'live' ? height : card) + "");
		// 		}	
		// 	};
		// }, 500);
	}
};

window.onload = function(){
	var card = document.getElementById("scoredetailCard");
	if (card.classList.contains('forward-card')) liveScore.init('shared');
	else liveScore.init('live');
};

function getInnerHTML(id){
	PlatformBridge.receiveInnerHTML(document.documentElement.outerHTML,id);
}

function setDataCallback(){
	liveScore.timer = setTimeout(liveScore.pollServerForNewScore, 0);
}
