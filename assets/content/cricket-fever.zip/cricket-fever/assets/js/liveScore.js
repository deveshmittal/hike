
var score = function(){};
score.prototype.setupEvents = function(){
	var that = this;

	events.subscribe('/score/updated/scaleDown', function(team){
		team.classList.remove('scale');
	});

	events.subscribe('/score/updated/', function(team){
		team.classList.add('scale');
		setTimeout(function(){
			events.publish('/score/updated/scaleDown', team);
		}, 500);
	});

	events.subscribe('/score/update/', function(res){
		if(res.team1.score){
			that.teamA.innerHTML = res.team1.score;
			if (res.team1.current) events.publish('/score/updated/', that.teamA);
		}
		if(res.team2.score){
			that.teamB.innerHTML = res.team2.score;
			if (res.team2.current) events.publish('/score/updated/', that.teamB);
		}
		if (res.team1.overs){
			that.teamAovers.innerHTML = res.team1.overs;
			that.teamAovers.classList.remove("yetTobat");

		} else {
			that.teamAovers.innerHTML = 'Yet to bat';
			that.teamAovers.classList.add("yetTobat");
		}
		if (res.team2.overs){
			that.teamBovers.innerHTML = res.team2.overs;
			that.teamBovers.classList.remove("yetTobat");

		} else {
			that.teamBovers.innerHTML = 'Yet to bat';
			that.teamBovers.classList.add("yetTobat");

		}		
	});

	events.subscribe('/score/refresh/', function(res){
		liveScore.pollServerForNewScore();
	});
};
score.prototype.init = function(el){
	this.teamA = el.querySelectorAll('.scoreFinal.alignLeft .teamScore')[0];
	this.teamAovers = el.querySelectorAll('.scoreFinal.alignLeft .teamOvers')[0];

	this.teamB = el.querySelectorAll('.scoreFinal.alignRight .teamScore')[0];
	this.teamBovers = el.querySelectorAll('.scoreFinal.alignRight .teamOvers')[0];

	this.setupEvents();
};

var liveScore = liveScore || {};
liveScore = {
	saveState: true,
	currentTemplate: '<table class="batting"><thead><tr class=""><td class="">BATSMEN</td><td>R</td><td>B</td><td>4s</td><td>6s</td><td>SR</td></tr></thead><tbody>        {{#battingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}            <td>{{runs}}</td>            <td>{{balls}}</td>            <td>{{fours}}</td>            <td>{{sixes}}</td>            <td>{{SR}}</td>          </tr>        {{/battingScore}}      </tbody>    </table>        <table class="bowling">      <thead >        <tr class="">          <td class="">BOWLERS</td>          <td>O</td>          <td>M</td>          <td>R</td>          <td>W</td>          <td>Econ</td>        </tr>      </thead>           <tbody>         {{#bowlingScore}}          <tr class="">            {{#current}}             <td class="playing currentPlayer">{{name}}*</td>            {{/current}}            {{^current}}             <td class="playing ">{{name}}</td>            {{/current}}          <td>{{overs}}</td>          <td>{{maidens}}</td>          <td>{{runs}}</td>          <td>{{wickets}}</td>          <td>{{econ}}</td>        </tr>      {{/bowlingScore}}              </tbody>    </table>    <table class="bowling">          </table>',
	bindEvents: function(){

		liveScore.heightTimer = false;
		
	    if (liveScore.card) {
	    	
            var iconDown = document.getElementsByClassName("icon-angle-down")[0];
            
            var tableHeight;
            var cardActionHeight;
            var cardIntroHeight;
            var showSummarryHeight;
            var maxheight;
            var minheight;

            var getHeights = function(){
            	tableHeight = (liveScore.table) ? liveScore.table.offsetHeight : 0;
	            cardActionHeight = liveScore.cardAction.offsetHeight;
	            cardIntroHeight = liveScore.cardIntro.offsetHeight;
	            showSummarryHeight = (liveScore.showSummarry) ? liveScore.showSummarry.offsetHeight : 0;
	            
	            maxheight = cardIntroHeight + showSummarryHeight + tableHeight + cardActionHeight;
	            minheight = cardIntroHeight + showSummarryHeight + cardActionHeight;
            };

            getHeights();

            document.getElementById('refreshScore').addEventListener('touchstart', function(event){
            	events.publish('/score/refresh/');
            });

	        liveScore.showSummarry.addEventListener("click", function(event) {
	        	event.stopPropagation();
	        	clearTimeout(liveScore.heightTimer);
	        	addRippleEffect(event);

                if (liveScore.card.classList.contains('pull')){
                	liveScore.card.classList.remove('pull');
                	iconDown.classList.remove("rotate");
                    iconDown.classList.add("rotateAgain");
                    iconDown.nextElementSibling.innerHTML = "View mini Scorecard";

                    setTimeout(function(){ PlatformBridge.onResize(minheight + "") }, 50);

                    liveScore.heightTimer = setTimeout(function(){
                    	getHeights();
                    	if (minheight < window.innerHeight)
                    		PlatformBridge.onResize(minheight + "");
                    }, 1000);
                } else {
                	liveScore.card.classList.add('pull');
                	iconDown.classList.remove("rotateAgain");
                    iconDown.classList.add("rotate");
                    iconDown.nextElementSibling.innerHTML = "Hide mini Scorecard";

                    PlatformBridge.onResize(maxheight + "");

                    liveScore.heightTimer = setTimeout(function(){
                    	getHeights();
                    	if (maxheight < window.innerHeight)
                    		PlatformBridge.onResize(maxheight + "");
                    }, 1000);
                }
	        });
	    }
	},
	pollServerForNewScore: function(){
		var that = this;

		if (platform.helperData != null) var url = platform.helperData.liveScorePollUrl;
		else return false;

		platform.ajaxCall("GET", url, function(response){
			
			// platform.log(response );
			platform.response = response;
			response = JSON.parse(response);
			clearTimeout(liveScore.timer);
			
			if (response.error ){
				platform.log("wrong match id");
				PlatformBridge.deleteAlarm();
				liveScore.timer = setTimeout(liveScore.pollServerForNewScore,  60000);

				events.publish('/score/refresh/stopAnimation/');
				return false;
			}

			switch(response.state){
				case "inprogress":
					events.publish('/score/update/', response);	

					if (liveScore.type === 'live') {
						var getTime = new Date().getTime();
						var polltime = response.nextPollTs - getTime;
						liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 30000 ? 30000 : polltime);
						liveScore.updateScore(response);
					}

					if(liveScore.saveState){

						var obj = {};
						var cardContainer = document.getElementById('scoredetailCard');

						obj["cardObj"]= {} ;
					  	obj["fwdCardObj"] = {} ;
					  	obj["cardObj"]["ld"] = response;
					  	obj["cardObj"]["layoutId"] = cardContainer.classList.contains('forward-card') ? "fwd_liveScore.html": "liveScore.html";
					  	obj["cardObj"]["h"] = "257";

					  	obj["fwdCardObj"]["ld"] = response;
					  	obj["fwdCardObj"]["layoutId"] = "fwd_liveScore.html";


					  	PlatformBridge.updateMetadata( JSON.stringify(obj), "false");
					  	
					 	
					  	platform.log("updatedMetadata called...converted to liveScore card");
					}

					if (liveScore.saveState){
						liveScore.saveState = false;
					} else {
						liveScore.saveState = true;
					}

					document.getElementById("status").innerHTML  = response.status;
				  	break;

				case "complete":
				case "mom":
				case "abandon":

					platform.log("in result state");

					var obj = {};
				  	obj["cardObj"]= {} ;
				  	obj["fwdCardObj"] = {} ;
				  	obj["cardObj"]["ld"] = response;

				  	if (liveScore.type == 'live') {
				  		obj["cardObj"]["layoutId"] = "resultMatch.html";
				  	} else {
			  			obj["cardObj"]["layoutId"] = "fwd_resultMatch.html";
			  		}
					obj["cardObj"]["h"] = "260";

				  	obj["fwdCardObj"]["ld"] = response;
				  	obj["fwdCardObj"]["layoutId"] = "fwd_resultMatch.html";

				  	platform.log("deleting alarm updating metadata");
				  	PlatformBridge.deleteAlarm();
				  	PlatformBridge.updateMetadata( JSON.stringify(obj), "true");

				  	platform.log("updatedMetadata called ...converted to result card");
				  	break;
				default:
					var getTime = new Date().getTime();
					var polltime = response.nextPollTs - getTime;
					liveScore.timer = setTimeout(liveScore.pollServerForNewScore, polltime < 60000 ? 60000 : polltime);

					document.getElementById("status").innerHTML  = response.status;
					platform.helperData.nextPollTs = response.nextPollTs;
					platform.log("in default");
					PlatformBridge.updateHelperData( JSON.stringify(platform.helperData) );

					if (liveScore.type === 'live') liveScore.updateScore(response);
						events.publish('/score/update/');
					break;
			};
		});
	},
	updateScore: function(data){
		document.getElementsByClassName("tableContainer")[0].innerHTML = Mustache.render(this.currentTemplate, data);
	},
	init: function(type){
		this.type = type;

		liveScore.cardIntro = document.getElementsByClassName('cardIntro')[0];
		liveScore.showSummarry = document.getElementById('showSummarry');
		liveScore.cardAction = document.getElementsByClassName('cardAction')[0];
		liveScore.table = document.getElementsByClassName('tableContainer')[0];
		liveScore.card = document.getElementById('scoredetailCard');
		
		if (type === 'live') this.bindEvents();
		
		this.instance = new score();
		this.instance.init(document.getElementById("scoredetailCard"));

		var cardActionHeight = liveScore.cardAction.offsetHeight;
        var cardIntroHeight = liveScore.cardIntro.offsetHeight;
        var showSummarryHeight = (liveScore.showSummarry) ? liveScore.showSummarry.offsetHeight : 0;
        var liveHeight = cardActionHeight + cardIntroHeight + showSummarryHeight;
        var fwdHeight = cardActionHeight + cardIntroHeight;

        platform.log('cardActionHeight: ' + cardActionHeight + ' & cardIntroHeight: ' + cardIntroHeight + ' & showSummarryHeight: ' + showSummarryHeight);
		platform.log('liveHeight: ' + liveHeight + ' & fwdHeight: ' + fwdHeight);

		if (type === 'live') PlatformBridge.onLoadFinished(liveHeight + "");
		else if (type === 'shared') PlatformBridge.onLoadFinished(fwdHeight + "");

		setTimeout(function(){

			cardActionHeight = liveScore.cardAction.offsetHeight;
	        cardIntroHeight = liveScore.cardIntro.offsetHeight;
	        showSummarryHeight = liveScore.showSummarry.offsetHeight;
	        liveHeight = cardActionHeight + cardIntroHeight + showSummarryHeight;
	        fwdHeight = cardActionHeight + cardIntroHeight;

	        platform.log('inside setTimeout');
	        platform.log('cardActionHeight: ' + cardActionHeight + ' & cardIntroHeight: ' + cardIntroHeight + ' & showSummarryHeight: ' + showSummarryHeight);
	        platform.log('liveHeight: ' + liveHeight + ' & fwdHeight: ' + fwdHeight);
            
			if ((window.innerHeight - (type === 'live' ? liveHeight : fwdHeight)) > 0){
				PlatformBridge.onResize(( type === 'live' ? liveHeight : fwdHeight) + "");
			}
		}, 1500);
	}
};

window.onload = function(){
	var card = document.getElementById("scoredetailCard");

	if (card.classList.contains('forward-card')) liveScore.init('shared');
	else liveScore.init('live');

	var teamOversEle = document.getElementsByClassName("teamOvers");
	if(teamOversEle.length){
		for(var i=0;i <teamOversEle.length; i++){
			if(teamOversEle[i].innerHTML == '()' || teamOversEle[i].innerHTML == ''){
				teamOversEle[i].innerHTML = 'Yet to bat';
				teamOversEle[i].classList.add('yetTobat') ;

			}
		}
	}
};

function getInnerHTML(id){
	PlatformBridge.receiveInnerHTML(document.documentElement.outerHTML,id);
}

function setDataCallback(){
	liveScore.timer = setTimeout(liveScore.pollServerForNewScore, 0);
}

function onResume(){
	platform.log("in on resume");
	liveScore.pollServerForNewScore();
	platform.log(" on resume called");
}

function onPause(){
	platform.log("in on pause");
	clearTimeout(liveScore.timer);
	platform.log(" on pause called");
}

