var fixture =  fixture || {};
fixture = {

	getHeights: function(){
		fixture.cardIntroHeight = fixture.cardIntro.offsetHeight;
		fixture.cardActionHeight = fixture.cardAction.offsetHeight;

		fixture.totalHeight = fixture.cardIntroHeight + fixture.cardActionHeight;
	},

	bindEvents : function(){

		// document.getElementById("refreshScore").addEventListener("click", function(event) {
  //       	event.stopPropagation();
  //       	addRippleEffect(event);
  //           fixture.callServerToChangeCard();
  //       });

        fixture.cardIntro = document.getElementsByClassName('cardIntro')[0];
        fixture.cardAction = document.getElementsByClassName('cardAction')[0];

        fixture.getHeights();
		PlatformBridge.onLoadFinished(fixture.totalHeight  + "");

		setTimeout(function(){
			var card = document.getElementById('fixtureCard').offsetHeight;
			if ((window.innerHeight - card) > 40){
				fixture.getHeights();
				PlatformBridge.onResize(fixture.totalHeight  + "");
			}
		}, 2000);
	},
	responseBack: function(response){
		platform.log(response);
	},
	callServerToChangeCard : function(){

		try{

			var fixtureCardContainer = document.getElementById("fixtureCard");
			if(typeof fixtureCardContainer !="undefined" && fixtureCardContainer!=null){
				var matchId = fixtureCardContainer.getAttribute("data-matchid"); 
			}	
			if(platform.helperData != null){
				var url = platform.helperData.liveScorePollUrl;
			}

			platform.ajaxCall("GET", url , function(response){
				


				var response = JSON.parse(response);
				if(response.error){
					platform.log("no data available for this matchId");
					
					if(platform.refreshClick){
						if(response.error.toLowerCase() == "no match found"){
							PlatformBridge.showToast("Match has not yet started.");
						}else{
							PlatformBridge.showToast("An error occurred. Please try later.");

						}
						platform.refreshClick = false;

					}	
				}
				if(response !=null && response.state){
				
					platform.log("state is "+response.state);

					switch(response.state){
						case "inprogress":
						case "innings break":
						case "delay":
						case "rain":
						case "badweather":
						case "badlight":
						case "dinner":
						case "innings":
						case "break":
						case "wetoutfield":
						case "lunch":
							if(response.team1 && response.team1.score!=null){
								platform.log("in live state");

								if(response.state == "inprogress") {
									var date = new Date();
									var alarmTime = (date.getTime()+10 ).toString();
									PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0}, "notification_sound": false, "notification": "'+ response.status+'",  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "1"}', alarmTime);

								}
								var obj ={};
								var cardContainer = document.getElementById('fixtureCard');

							  	obj["cardObj"]= {} ;
							  	obj["fwdCardObj"] = {} ;
							  	obj["cardObj"]["ld"] = response;
							  	obj["cardObj"]["layoutId"] = cardContainer.classList.contains('forward-card') ? "fwd_liveScore.html": "liveScore.html";
							  	obj["cardObj"]["h"] = "257";

							  	obj["fwdCardObj"]["ld"] = response;
							  	obj["fwdCardObj"]["layoutId"] = "fwd_liveScore.html";

							  	PlatformBridge.deleteAlarm();
							  	PlatformBridge.updateMetadata( JSON.stringify(obj) , "true");
							  	var analyticEvents = {};
								analyticEvents["ek"] = "card_stchg";
								analyticEvents["state"] = "fix_live";	
								analyticEvents["matchId"] = response.matchId;

								platform.logAnalytics("true", "view",analyticEvents);
							  	platform.log("updatedMetadata called...converted to liveScore card");

							  }else{
							  		fixture.updateCurrentStatusOfMatch(response);
							  }
							  	break;
						  	
						case "complete":
						case "mom":
						case "abandon" :

							platform.log("in result state");
							var obj = {};

						  	obj["cardObj"]= {} ;
						  	obj["fwdCardObj"] = {} ;
						  	obj["cardObj"]["ld"] = response;
						  	obj["cardObj"]["layoutId"] = "resultMatch.html";
						  	obj["cardObj"]["h"] = "236";

						  	obj["fwdCardObj"]["ld"] = response;
						  	obj["fwdCardObj"]["layoutId"] = "fwd_resultMatch.html";

						  	platform.log("deleting alarm updating metadata");

						  	PlatformBridge.deleteAlarm();

						  	platform.helperData.isAlarmSet = false;
							platform.helperData.nextPollTs = response.nextPollTs;
							platform.helperData.status = response.status;

							PlatformBridge.updateHelperData(JSON.stringify(platform.helperData) );

						  	PlatformBridge.updateMetadata(JSON.stringify(obj), "true");

						  	platform.log("updatedMetadata called ...converted to result card");
					  		var analyticEvents = {};
							analyticEvents["ek"] = "card_stchg";
							analyticEvents["state"] = "fix_res";	
							analyticEvents["matchId"] = response.matchId;

							platform.logAnalytics("true", "view",analyticEvents);

						  	break;
						default:
							fixture.updateCurrentStatusOfMatch(response);
							
							break;
					}
				}
			});
		}
		catch(e){
			platform.log(e.message);

			if(platform.helperData !=null && platform.helperData.debug){

			   	var analyticEvents = {};
				analyticEvents["ek"] = e.message;
				analyticEvents["state"] = platform.card;	
				analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

				platform.logAnalytics("false", "html_error", analyticEvents);
			}
			if(platform.refreshClick){
				PlatformBridge.showToast("An error occurred. Please try later.");
				platform.refreshClick = false;

			}	
		}
	},	

	updateCurrentStatusOfMatch: function(response){
		platform.log("in default");
		document.getElementById("status").innerHTML = response.status;
		document.getElementById("status").className = document.getElementById("status").className+ " status";

		platform.helperData.isAlarmSet = false;
		platform.helperData.nextPollTs = response.nextPollTs;
		platform.helperData.status = response.status;

		fixture.pokeHikeServer();
		PlatformBridge.updateHelperData( JSON.stringify(platform.helperData) );
		platform.log(JSON.stringify(platform.helperData));

		fixture.getHeights();
		PlatformBridge.onResize(fixture.totalHeight + "");
		
		setTimeout(function(){
			var card = document.getElementById('fixtureCard').offsetHeight;
			if (window.innerHeight > card){
				fixture.getHeights();
				PlatformBridge.onResize(fixture.totalHeight + "");		
			}
		}, 1000);
	},

	pokeHikeServer : function(){
		try{
			
			if(platform.helperData.status){
				document.getElementById("status").innerHTML  = platform.helperData.status;
				document.getElementById("status").className  = document.getElementById("status").className+ " status";

				setTimeout(function(){
					var card = document.getElementById('fixtureCard').offsetHeight;
					PlatformBridge.onResize(card  + "");
					platform.log('onresize height called(#120): ' + card);
					// document.getElementsByClassName('timings')[0].innerHTML += '(' + card + ')';
				}, 300);
			}
			if(platform.helperData != null && !platform.helperData.isAlarmSet  ){
				platform.log("in alarm");
				if(platform.helperData.nextPollTs !=null){
					var nextPollTs = platform.helperData.nextPollTs.toString();
				}	
				platform.log("alarmSetCalling");
				platform.log(""+nextPollTs+platform.msisdn );
				
				
				PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0},  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "1"}', nextPollTs);
				platform.log("alarmSetCalled" );

				platform.helperData.isAlarmSet = true;
				PlatformBridge.updateHelperData( JSON.stringify(platform.helperData) );
			}
		}
		catch(e){
			platform.log(e.message);

			if(platform.helperData !=null && platform.helperData.debug){

			   	var analyticEvents = {};
				analyticEvents["ek"] = e.message;
				analyticEvents["state"] = platform.card;	
				analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

				platform.logAnalytics("false", "html_error", analyticEvents);
			}
			
	    			
		}
	}

}

function returnCurrentFixture() {
  	platform.log( "stop event occured" );
}

function alarmPlayed(){
	platform.refreshClick = false;
	platform.log("alarmPlayed");

	fixture.callServerToChangeCard();
}

function setDataCallback(){
	fixture.pokeHikeServer();
}

window.onload = function(){
	fixture.bindEvents();
};

platform.card = document.getElementById('fixtureCard').classList.contains('forward-card') ? "fwd_fixture": "fixture";



