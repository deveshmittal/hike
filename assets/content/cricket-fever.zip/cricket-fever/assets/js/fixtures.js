var fixture =  fixture || {};
fixture = {

	bindEvents : function(){

		document.getElementById("refreshScore").addEventListener("touchstart", function(event) {
        	event.stopPropagation();
            fixture.callServerToChangeCard();
        });

		var card = document.getElementById('fixtureCard').clientHeight;
		platform.log('onload height called: ' + card);
		PlatformBridge.onLoadFinished(card  + "");

		setTimeout(function(){
			var card = document.getElementById('fixtureCard').clientHeight;
			if ((window.innerHeight - card) > 40){
				platform.log('onresize height called: ' + card);
				PlatformBridge.onResize(card  + "");
			}
		}, 500);
	},
	responseBack: function(response){
		platform.log(response);
	},
	callServerToChangeCard : function(){

		try{

			var fixtureCardContainer = document.getElementById("fixtureCard");
			if(typeof fixtureCardContainer !="undefined" && fixtureCardContainer!=null){
				var matchId = fixtureCardContainer.getAttribute("data-matchid"); 
			}	
			if(platform.helperData != null){
				var url = platform.helperData.liveScorePollUrl;
			}

			platform.ajaxCall("GET", url , function(response){
				
				platform.log(response);

				var response = JSON.parse(response);
				if(response !=null && response.state){
				
					platform.log("state is "+response.state);

					switch(response.state){
						case "inprogress":

							platform.log("in live state");

							var obj ={};
						  	obj["cardObj"]= {} ;
						  	obj["fwdCardObj"] = {} ;
						  	obj["cardObj"]["ld"] = response;
						  	obj["cardObj"]["layoutId"] = "liveScore.html";
						  	obj["cardObj"]["h"] = "257";

						  	obj["fwdCardObj"]["ld"] = response;
						  	obj["fwdCardObj"]["layoutId"] = "fwd_liveScore.html";

						  	PlatformBridge.deleteAlarm(platform.messageId);
						  	PlatformBridge.updateMetadata(platform.messageId, JSON.stringify(obj) , "true");

						  	platform.log("updatedMetadata called...converted to liveScore card");

						  	break;
						case "complete":
						case "mom":
						case "abandon" :

							platform.log("in result state");
							var obj = {};

						  	obj["cardObj"]= {} ;
						  	obj["fwdCardObj"] = {} ;
						  	obj["cardObj"]["ld"] = response;
						  	obj["cardObj"]["layoutId"] = "resultMatch.html";
						  	obj["cardObj"]["h"] = "236";

						  	obj["fwdCardObj"]["ld"] = response;
						  	obj["fwdCardObj"]["layoutId"] = "fwd_resultMatch.html";

						  	platform.log("deleting alarm updating metadata");

						  	PlatformBridge.deleteAlarm(platform.messageId);
						  	PlatformBridge.updateMetadata(platform.messageId, JSON.stringify(obj), "true");

						  	platform.log("updatedMetadata called ...converted to result card");

						  	break;
						default:
							
							platform.log("in default");
							document.getElementById("status").innerHTML  = response.status;
							setTimeout(function(){
								var card = document.getElementById('fixtureCard').clientHeight;
								PlatformBridge.onResize(card  + "");
								platform.log('onresize height called(#93): ' + card);
							}, 300);
							platform.helperData.isAlarmSet = false;
							platform.helperData.nextPollTs = response.nextPollTs;
							platform.helperData.status = response.status;

							fixture.pokeHikeServer();
							PlatformBridge.updateHelperData(platform.messageId, JSON.stringify(platform.helperData) );
							platform.log(JSON.stringify(platform.helperData));
							break;
					}
				}
			});
		}
		catch(e){
			platform.log(e.message);
		}
	},	

	pokeHikeServer : function(){
		try{
			
			if(platform.helperData.status){
				document.getElementById("status").innerHTML  = platform.helperData.status;
				setTimeout(function(){
					var card = document.getElementById('fixtureCard').clientHeight;
					PlatformBridge.onResize(card  + "");
					platform.log('onresize height called(#120): ' + card);
					// document.getElementsByClassName('timings')[0].innerHTML += '(' + card + ')';
				}, 300);
			}
			if(platform.helperData != null && !platform.helperData.isAlarmSet  ){
				platform.log("in alarm");
				if(platform.helperData.nextPollTs !=null){
					var nextPollTs = platform.helperData.nextPollTs.toString();
				}	
				platform.log("alarmSetCalling");
				platform.log(""+nextPollTs+platform.msisdn+ platform.messageId );
				
				var isNotification = false;
				if(platform.helperData.status && platform.helperData.status == "toss"){
					PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0}, "notification_sound": '+isNotification+', "notification": "'+platform.helperData.status+'",  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "1"}',platform.messageId, nextPollTs);
				}else{
					PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0},  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "1"}',platform.messageId, nextPollTs);

				}

				platform.log("alarmSetCalled" );

				platform.helperData.isAlarmSet = true;
				PlatformBridge.updateHelperData(platform.messageId, JSON.stringify(platform.helperData) );
			}
		}
		catch(e){
			platform.log(e.message);

		}
	}

}

function returnCurrentFixture() {
  	platform.log( "stop event occured" );
}

function alarmPlayed(){
	platform.log("alarmPlayed");
	fixture.callServerToChangeCard();
}

function setDataCallback(){
	fixture.pokeHikeServer();
}

window.onload = function(){
	fixture.bindEvents();
};

