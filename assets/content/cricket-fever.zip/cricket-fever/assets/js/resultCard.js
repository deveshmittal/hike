var resultCard = resultCard || {};
resultCard = {
	bindEvents: function(){
		var card = document.getElementById('matchResultCard').offsetHeight;
		PlatformBridge.onLoadFinished(card  + "");

		setTimeout(function(){
			var card = document.getElementById('matchResultCard').offsetHeight;
			if ((window.innerHeight - card) > 40){
				PlatformBridge.onResize(card  + "");
			}
		}, 1000);
	}
};

window.onload = function(){
	resultCard.bindEvents();

	var teamOversEle = document.getElementsByClassName("teamOvers");
	if(teamOversEle.length){
		for(var i=0;i <teamOversEle.length; i++){
			if(teamOversEle[i].innerHTML == '()'){
				teamOversEle[i].innerHTML = '';
			}
		}
	}	
};

function setDataCallback(){

	var card = document.getElementById("matchResultCard");
	
	if (!card.classList.contains('forward-card')) 
	{
		
		platform.log("deleting card at "+ platform.helperData.nextPollTs);
		PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0}, "notification_sound": 0, "notification": "'+platform.helperData.status+'",  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "0", "delete_card": true}', platform.helperData.nextPollTs.toString());
	}
}

function alarmPlayed(){
	platform.log("alarmPlayed");
}

platform.card = document.getElementById('matchResultCard').classList.contains('forward-card') ? "fwd_resultMatch": "resultMatch";
