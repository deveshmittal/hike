var introCard = {
	bindEvents: function(){
		var card = document.getElementById('introCard').offsetHeight;
		PlatformBridge.onLoadFinished(card  + "");

		setTimeout(function(){
			var card = document.getElementById('introCard').offsetHeight;
			if ((window.innerHeight - card) > 0){
				PlatformBridge.onResize(card  + "");
			}
		}, 1000);
	}
};

window.onload = function(){
	introCard.bindEvents();
};

function setDataCallback(){

	var card = document.getElementById("introCard");
	
	// if (!card.classList.contains('forward-card')) 
	// {
	// 	platform.log("deleting card at "+ platform.helperData.nextPollTs);
	// 	PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0}, "notification_sound": 0, "notification": "'+platform.helperData.status+'",  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "0", "delete_card": true}', platform.helperData.nextPollTs.toString());
	// }
}