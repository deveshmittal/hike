var introCard = {
	bindEvents: function(){

		if(document.getElementById("introCard")){
		var card = document.getElementById('introCard').offsetHeight;

		}
		if(document.getElementById("ftueCard")){
		var card = document.getElementById('ftueCard').offsetHeight;

		}
		PlatformBridge.onLoadFinished(card  + "");

		var closeIcon = document.getElementsByClassName('icon-close');
		if(closeIcon.length){
			var delCard = closeIcon[0];
			delCard.addEventListener('click', function(event){
				var analyticEvents = {};
				analyticEvents["ek"] = "card_introdel";
				platform.logAnalytics("true", "click",analyticEvents);
				PlatformBridge.deleteMessage();

			});
		}


		setTimeout(function(){
if(document.getElementById("introCard")){
		var card = document.getElementById('introCard').offsetHeight;

		}
		if(document.getElementById("ftueCard")){
		var card = document.getElementById('ftueCard').offsetHeight;

		}			if ((window.innerHeight - card) > 0){
				PlatformBridge.onResize(card  + "");
			}
		}, 1000);
	},
	checkStatusBlock: function (obj) {

		var analyticEvents = {};
		analyticEvents["ek"] = "optin";
		analyticEvents["choice"]="yes";

		if(obj.innerHTML.toUpperCase().indexOf("NO")!= -1 ){
			analyticEvents["choice"]="no";
			PlatformBridge.blockChatThread();
		}

		platform.log("blocked");
		var obj ={};
		var title=document.getElementsByClassName("title")[0].innerHTML;
		var message = document.getElementsByClassName("question")[0].getAttribute("data-nextQuestion");
		var hint=document.getElementsByClassName("hint")[0].innerHTML;

	  	obj["cardObj"]= {} ;
	  	obj["fwdCardObj"] = {} ;
	  	obj["cardObj"]["ld"] = {"title": title, "question2": message, "hint": hint};
	  	obj["cardObj"]["layoutId"] = "ftue-mute.html";
	  	obj["cardObj"]["h"] = "257";

	  	obj["fwdCardObj"]["ld"] = {"title": title, "question2": message, "hint": hint};	
	  	obj["fwdCardObj"]["layoutId"] = "ftue-mute.html";
	  	platform.logAnalytics("true", "click",analyticEvents);
	  	PlatformBridge.updateMetadata( JSON.stringify(obj) , "true");
	  	platform.log("changed to 2nd question");


	},
	checkStatusMute: function (obj) {
		var analyticEvents = {};
		analyticEvents["ek"] = "notification";
		analyticEvents["choice"]="yes";

		if(obj.innerHTML.toUpperCase().indexOf("NO")!= -1 ){
			analyticEvents["choice"]="no";

			PlatformBridge.muteChatThread();
		}
		platform.log("muted");

		platform.logAnalytics("true", "click",analyticEvents);

		PlatformBridge.deleteMessage();
		platform.log("deleted");


	}
};

// window.onload = function(){
// 	introCard.bindEvents();
// };

function setDataCallback(){

	// var card = document.getElementById("ftueCard");
	
	// if (!card.classList.contains('forward-card')) 
	// {
	// 	platform.log("deleting card at "+ platform.helperData.nextPollTs);
	// 	PlatformBridge.setAlarm('{"alarm_data": {"isAlarmSet": 0}, "notification_sound": 0, "notification": "'+platform.helperData.status+'",  "conv_msisdn" :"'+platform.msisdn+'", "inc_unread": "0", "delete_card": true}', platform.helperData.nextPollTs.toString());
	// }
}

var fireappload = events.subscribe('/fire/page/load/', function(){
	introCard.bindEvents();
	fireappload.remove();
});
PlatformBridge.setDebuggableEnabled(true);
events.publish('/platform/app.init/');