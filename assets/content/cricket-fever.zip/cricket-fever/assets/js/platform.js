
/*
 * Minimal classList shim for IE 9
 * By Devon Govett
 * MIT LICENSE
 */
if(!("classList"in document.documentElement)&&Object.defineProperty&&typeof HTMLElement!=="undefined"){Object.defineProperty(HTMLElement.prototype,"classList",{get:function(){function t(t){return function(n){var r=e.className.split(/\s+/),i=r.indexOf(n);t(r,i,n);e.className=r.join(" ")}}var e=this;var n={add:t(function(e,t,n){~t||e.push(n)}),remove:t(function(e,t){~t&&e.splice(t,1)}),toggle:t(function(e,t,n){~t?e.splice(t,1):e.push(n)}),contains:function(t){return!!~e.className.split(/\s+/).indexOf(t)},item:function(t){return e.className.split(/\s+/)[t]||null}};Object.defineProperty(n,"length",{get:function(){return e.className.split(/\s+/).length}});return n}})} 

var events = (function(){
	var topics = {};
	var hOP = topics.hasOwnProperty;

	return {
    	subscribe: function(topic, listener) {
      		if(!hOP.call(topics, topic)) topics[topic] = [];
      		var index = topics[topic].push(listener) -1;
  			return {
    			remove: function() {
      				delete topics[topic][index];
    			}
  			};
    	},
    	publish: function(topic, info) {
			if(!hOP.call(topics, topic)) return;
      		topics[topic].forEach(function(item) {
      			item(info != undefined ? info : {});
      		});
    	}
  	};
})();

var platform = platform = {
	refreshClick: false,
	helperData: {"layoutId": "fixture", "isAlarmSet": false},
	msisdn: '',
	config: {},
	response: '',
	bindEvents: function(){
		var links =  document.querySelectorAll('body a');

		var fwd = document.getElementsByClassName('icon-redo2')[0];
		var refresh = document.getElementsByClassName('icon-cog')[0];
		var shareCard = document.getElementById("shareCard");
		var shareMessage;
		var captionText;
		events.subscribe('/score/refresh/startAnimation/', function(){
			document.getElementsByClassName('icon-cog')[0].classList.add('play');
		});

		events.subscribe('/score/refresh/stopAnimation/', function(){
			document.getElementsByClassName('icon-cog')[0].classList.remove('play');
		});

		if(typeof shareCard !="undefined"){
			shareCard.addEventListener('click', function(e){
				e.preventDefault();
				e.stopPropagation();
			//	addRippleEffect(e);

				platform.log("share calling");

				if(platform.helperData!=null && platform.helperData.share_text){
					shareMessage = platform.helperData.share_text;
				}else{
					shareMessage ="World Cup 2015 Live scores only on hike!" ;
				}
				if(platform.helperData!=null && platform.helperData.caption_text){
					captionText = platform.helperData.caption_text;
				}else{
					captionText = "";
				}

				PlatformBridge.share(shareMessage, captionText);
				platform.log("share called");

			    var analyticEvents = {};
				analyticEvents["ek"] = "card_share";
				analyticEvents["state"] = platform.card;	
				analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

    			platform.logAnalytics("true", "click",analyticEvents);
	    			
				return false;
			});
		}

		if(typeof fwd !="undefined"){
			fwd.addEventListener('click', function(e){
				e.preventDefault();
				e.stopPropagation();
			//	addRippleEffect(e);

				platform.log("forward calling");
				PlatformBridge.forwardToChat( platform.response);
				platform.log("forward callied  with json="+platform.response );

			    var analyticEvents = {};
				analyticEvents["ek"] = "card_fwd";
				analyticEvents["state"] = platform.card;	
				analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

    			platform.logAnalytics("true", "click",analyticEvents);
	    			
				return false;
			});
		}

		if(typeof refresh !="undefined"){
			refresh.addEventListener('click', function(e){
				platform.refreshClick = true;
				e.preventDefault();
			//	addRippleEffect(e);

				if (typeof liveScore!="undefined" && liveScore !=null){
					events.publish('/score/refresh/', true);
				} else {
					fixture.callServerToChangeCard();
				}

				return false;
			});
		}

		if (links.length){
			platform.log("links found");
			for(var i=0; i<links.length; i++){
				links[i].onclick = function(event){
					platform.log("link clicked ");
					event.preventDefault();
		    		event.stopPropagation();
		    		// if(this.classList.contains("tappingEffect") != -1){
		    		// 	addRippleEffect(event);
		    		// }

					var href = this.getAttribute("data-href");
	    			platform.log(href);
	    			if (href != null && document.getElementsByClassName("title").length){
	    				var title = document.getElementsByClassName("title")[0].innerHTML;
	    				platform.log("in bridge calling full page");
	    				PlatformBridge.openFullPage(title, href);
	    				platform.log("link opened ");

	    			}

	    			var analyticEvents = {};
					analyticEvents["ek"] = "card_vfs";
					analyticEvents["state"] = platform.card;	
					analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

					if(this.parentNode.classList.contains("cardAction")){
						analyticEvents["ek"] = "card_mwc";

	    			}
	    			platform.logAnalytics("true", "click",analyticEvents);
				}
			} 	
		}
		var tappedElementCount = document.getElementsByClassName("tappingEffect");

		if(tappedElementCount.length){
			for(var i=0; i< tappedElementCount.length;i++){
				tappedElementCount[i].addEventListener("touchstart", function(){
					this.classList.add("tapped");
				});
				tappedElementCount[i].addEventListener("touchend", function(){
					this.classList.remove("tapped");
				});
				tappedElementCount[i].addEventListener("touchcancel", function(){
					this.classList.remove("tapped");
				});
				tappedElementCount[i].addEventListener("touchleave", function(){
					this.classList.remove("tapped");
				});
			}
		}
       
	},
    ajaxCall: function(type, url, callback, data, headers) {
		if(platform.msisdn){
			if(url.indexOf("?")!=-1){
				url = url +'&query=' + encodeURIComponent(platform.msisdn);
			}else{
				url = url +'?query=' + encodeURIComponent(platform.msisdn);
			}

		}
    	platform.log("ajax call started on "+ url);
      	var xhr = new XMLHttpRequest();
      	var timeout = setTimeout(function(){
      		events.publish('/score/refresh/stopAnimation/');
      	}, 10000);

      	if (xhr) {
          	xhr.onreadystatechange = function() {
           		if( 4 == xhr.readyState && 200 == xhr.status ){ 
           			clearTimeout(timeout);
           			if (callback) callback(xhr.responseText);
           			events.publish('/score/refresh/stopAnimation/');
           			platform.log("ajax call finished on "+ url);
           			platform.refreshClick = false;

           		}
           		if(  4 == xhr.readyState && 200 != xhr.status )  {
           			clearTimeout(timeout);
           			events.publish('/score/refresh/stopAnimation/');
           			platform.log("ajax call error occurred on "+ url);
           			if(platform.refreshClick){
						PlatformBridge.showToast("An error occurred. Please try later.");
						platform.refreshClick = false;

					}

					if(platform.helperData !=null && platform.helperData.debug){

					   	var analyticEvents = {};
						analyticEvents["ek"] = "ajax call error occurred on "+ url;
						analyticEvents["state"] = platform.card;	
						analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

						platform.logAnalytics("false", "html_error", analyticEvents);
					}
           		}

           		platform.log('ajax ended with readyState: ' + xhr.readyState + ' and status: ' + xhr.status);

          	}

          	var datatype = Object.prototype.toString.call(data);
          	if (datatype === '[object Object]') data = JSON.stringify(data);
			
			events.publish('/score/refresh/startAnimation/');
			platform.log('ajax beforeSend');
          	xhr.open(type, url, true);
          	xhr.send(data);
      	}
	},

	callHike : function(name, args){
	 	//AndroidFunction[name].apply(null, args);
	 	//fixture.setAlarm();
	},

	setHelperData: function(){

	},

	getHelperData: function(){

	},

	log: function (message) {
		PlatformBridge.logFromJS("cricket-fever", message);
		console.log(message);
	},

	debug: function(object){
		PlatformBridge.logFromJS("cricket-fever", JSON.stringify(object));
	},
	logAnalytics: function(isUI, type, analyticEvents){
		analyticEvents = JSON.stringify(analyticEvents);

		PlatformBridge.logAnalytics(isUI, type,analyticEvents );
		platform.log("analytic with isui = "+ isUI + " type = "+ type + " analyticEvents = "+ analyticEvents);
	}

};

function onStop (func) {
	func();
}

function setData(msisdn, helperData){
	platform.log("inSetData");

	if(!msisdn){
		platform.log("msisdn is null");
	}
	
	else{
		platform.log("msisdn: "+msisdn);
		platform.log("helperData: "+helperData);

		platform.msisdn = msisdn;

		if (helperData != null && helperData !=''){
			platform.helperData = JSON.parse(helperData);
			if(typeof platform.helperData.debug == "undefined" ) {
				platform.helperData.debug = true;
			}
		}

		setDataCallback();
	}
}

function pullNavigator(){
	platform.debug(navigator);
};

function onResume(){
	platform.log("in on resume");
	if (typeof liveScore != "undefined" && liveScore != null) liveScore.pollServerForNewScore();
	platform.log(" on resume called");
}

function onPause(){
	platform.log("in on pause");
	if (typeof liveScore != "undefined" && liveScore != null) clearTimeout(liveScore.timer);
	platform.log(" on pause called");
}

window.onerror = function(error, url, line){
	// platform.debug({'type': 'jserror', 'text': error, 'file': url, 'line': line});
	platform.log('error: ' + error + url + line);
	if(platform.helperData !=null && platform.helperData.debug){
		
		var analyticEvents = {};
		analyticEvents["ek"] = error;
		analyticEvents["state"] = platform.card;	
		analyticEvents["line"] = line;	

		analyticEvents["matchId"] = document.getElementsByClassName("cricket-card")[0].getAttribute("data-matchid");

		platform.logAnalytics("false", "html_error",analyticEvents);
	}
};

window.onload = function(){
	
};


var addRippleEffect = function (e) {
    var target = e.target;
    if(target.tagName == "IMG" || target.tagName == "img"  ){
    	target = target.parentNode;
    }
    var rect = target.getBoundingClientRect();
    var ripple = target.querySelector('.ripple');
    if (!ripple) {
        ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.height = ripple.style.width = Math.max(rect.width, rect.height) + 'px';
        target.appendChild(ripple);
    }
    ripple.classList.remove('show');
    var top = e.pageY - rect.top - ripple.offsetHeight / 2 - document.body.scrollTop;
    var left = e.pageX - rect.left - ripple.offsetWidth / 2 - document.body.scrollLeft;
    ripple.style.top = top + 'px';
    ripple.style.left = left + 'px';
    ripple.classList.add('show');
    return false;
}

function progressFinished(){
	
}

platform.bindEvents();
