
/*
 * Minimal classList shim for IE 9
 * By Devon Govett
 * MIT LICENSE
 */
if(!("classList"in document.documentElement)&&Object.defineProperty&&typeof HTMLElement!=="undefined"){Object.defineProperty(HTMLElement.prototype,"classList",{get:function(){function t(t){return function(n){var r=e.className.split(/\s+/),i=r.indexOf(n);t(r,i,n);e.className=r.join(" ")}}var e=this;var n={add:t(function(e,t,n){~t||e.push(n)}),remove:t(function(e,t){~t&&e.splice(t,1)}),toggle:t(function(e,t,n){~t?e.splice(t,1):e.push(n)}),contains:function(t){return!!~e.className.split(/\s+/).indexOf(t)},item:function(t){return e.className.split(/\s+/)[t]||null}};Object.defineProperty(n,"length",{get:function(){return e.className.split(/\s+/).length}});return n}})} 


var events = (function(){
	var topics = {};
	var hOP = topics.hasOwnProperty;

	return {
    	subscribe: function(topic, listener) {
      		if(!hOP.call(topics, topic)) topics[topic] = [];
      		var index = topics[topic].push(listener) -1;
  			return {
    			remove: function() {
      				delete topics[topic][index];
    			}
  			};
    	},
    	publish: function(topic, info) {
			if(!hOP.call(topics, topic)) return;
      		topics[topic].forEach(function(item) {
      			item(info != undefined ? info : {});
      		});
    	}
  	};
})();

var platform = platform = {

	helperData: {"layoutId": "fixture", "isAlarmSet": false},
	messageId: '',
	msisdn: '',
	config: {},
	response: '',
	bindEvents: function(){
		var links =  document.querySelectorAll('body a');

		var fwd = document.getElementsByClassName('icon-redo2')[0];
		var refresh = document.getElementsByClassName('icon-cog')[0];

		events.subscribe('/score/refresh/startAnimation/', function(){
			document.getElementsByClassName('icon-cog')[0].classList.add('play');
		});

		events.subscribe('/score/refresh/stopAnimation/', function(){
			document.getElementsByClassName('icon-cog')[0].classList.remove('play');
		});

		if(typeof fwd !="undefined"){
			fwd.addEventListener('touchstart', function(e){
				e.preventDefault();
				e.stopPropagation();
				platform.log("forward calling");
				PlatformBridge.forwardToChat(platform.messageId, platform.response);
				platform.log("forward callied  with messageId="+ platform.messageId+ ", json="+platform.response );
				return false;
			});
		}

		if(typeof refresh !="undefined"){
			refresh.addEventListener('touchstart', function(e){
				e.preventDefault();
				events.publish('/score/refresh/');
				return false;
			});
		}

		if (links.length){
			platform.log("links found");
			for(var i=0; i<links.length; i++){
				links[i].onclick = function(event){
					platform.log("link clicked ");
					event.preventDefault();
		    		event.stopPropagation();

	    			var href = this.getAttribute("data-href");
	    			platform.log(href);
	    			if (href != null && document.getElementsByClassName("title").length){
	    				var title = document.getElementsByClassName("title")[0].innerHTML;
	    				platform.log("in bridge calling full page");
	    				PlatformBridge.openFullPage(title, href);
	    				platform.log("link opened ");

	    			}
				}
			} 	
		}
		var tappedElementCount = document.getElementsByClassName("tappingEffect");

		if(tappedElementCount.length){
			for(var i=0; i< tappedElementCount.length;i++){
				tappedElementCount[i].addEventListener("touchstart", function(){
					this.classList.add("tapped");
				});
				tappedElementCount[i].addEventListener("touchend", function(){
					this.classList.remove("tapped");
				});
				tappedElementCount[i].addEventListener("touchcancel", function(){
					this.classList.remove("tapped");
				});
				tappedElementCount[i].addEventListener("touchleave", function(){
					this.classList.remove("tapped");
				});
			}
		}
       
	},
    ajaxCall: function(type, url, callback, data, headers) {
    	platform.log("ajax call started on "+ url);
      	var xhr = new XMLHttpRequest();
      	var timeout = setTimeout(function(){
      		events.publish('/score/refresh/stopAnimation/');
      	}, 10000);

      	if (xhr) {
          	xhr.onreadystatechange = function() {
           		if( 4 == xhr.readyState && 200 == xhr.status ){ 
           			clearTimeout(timeout);
           			if (callback) callback(xhr.responseText);
           			events.publish('/score/refresh/stopAnimation/');
           			platform.log("ajax call finished on "+ url);
           		}
           		if( 4 == xhr.readyState && 200 != xhr.status ){
           			clearTimeout(timeout);
           			events.publish('/score/refresh/stopAnimation/');
           			platform.log("ajax call error occurred on "+ url);
           		}
          	}

          	var datatype = Object.prototype.toString.call(data);
          	if (datatype === '[object Object]') data = JSON.stringify(data);
			
			events.publish('/score/refresh/startAnimation/');
          	xhr.open(type, url, true);
          	xhr.send(data);
      	}
	},

	callHike : function(name, args){
	 	//AndroidFunction[name].apply(null, args);
	 	//fixture.setAlarm();
	},

	setHelperData: function(){

	},

	getHelperData: function(){

	},

	log: function (message) {
		PlatformBridge.logFromJS("cricket-fever", message);
		console.log(message);
	},

	debug: function(object){
		PlatformBridge.logFromJS("cricket-fever", JSON.stringify(object));
	}
};

function onStop (func) {
	func();
}

function setData(messageId, msisdn, helperData){
	platform.log("inSetData");

	if(!messageId){
		platform.log("messageId is null");
	}

	if(!msisdn){
		platform.log("msisdn is null");
	}
	
	if(messageId){

		platform.messageId = messageId;
		platform.msisdn = msisdn;

		if (helperData != null && helperData !=''){
			platform.helperData = JSON.parse(helperData);
		}
		platform.log("messageId: "+platform.messageId);
		platform.log("msisdn: "+platform.msisdn);
		platform.log("helperData: "+helperData);

		setDataCallback();
	}	
}

function pullNavigator(){
	platform.debug(navigator);
};

window.onerror = function(error, url, line){
	// platform.debug({'type': 'jserror', 'text': error, 'file': url, 'line': line});
	platform.log('error: ' + error + url + line);
};

window.onload = function(){
	
};

platform.bindEvents();
